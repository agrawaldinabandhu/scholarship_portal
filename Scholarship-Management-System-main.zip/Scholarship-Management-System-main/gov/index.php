<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Government </title>
    <link rel="stylesheet" href="css/style2.css">
   
</head>
<body>
    <section>

        <nav>
            <h1> Government </h1>
            <div class="navlink">

                <ul>
                   <li><a href="about.html">About</a></li>
                     <li><a href="login.php">Login</a></li>
                </ul>
            </div>
        </nav>
    </section>
       <section>
            <div class = "image">
                <centre><img src = "/dashboard/Mini_project/i1.jpg"></centre>
            </div>      
           <div class="main">
               <div class="sub">
                <a href="login.php">POST MATRIC SCHORLARSHIP</a>
                </div>
    
                </div>
           </div>
       </section>  
  
</body>
</html>