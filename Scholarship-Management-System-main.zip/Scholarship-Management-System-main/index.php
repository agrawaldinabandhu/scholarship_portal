<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schorlarship</title>
    <link rel="stylesheet" href="css/style.css">
   
</head>
<body>
    <section>

        <nav>
            <h1>Schorlarship</h1>
            <div class="navlink">

                <ul>
                   <li><a href="about.php">About</a></li>
                     <li><a href="login.php">Login</a></li>
                </ul>
            </div>
        </nav>
    </section>
    <a href="registration.php"><marquee>Apply Post Matric Schorlarship Till 15 February 2022 </marquee></a>
       <section>
           <div class="main">
               <div class="sub">
                   <a href="registration.php">CREATE ACCOUNT FOR SCHORLARSHIP<div class="sub1">STUDENT-REGISTER</div></a>
               </div>
               <div class="sub">
                <a href="login.php">POST MATRIC SCHORLARSHIP<div class="sub1">STUDENT-LOGIN</div></a>
                </div>
                <div class="info"><p>Eligibility</p>
                    <ul>
                        <li>Student of <strong>Backward caste , Minority , OBC</strong> are Eligible </li>
                        <li>Income Should Be <strong>Less Than 1 Lakh</strong></li>
                        
                    </ul>
                </div>
                <div class="info"><p>INFORMATION</p>
                    <ul>
                        <li>College Registration Number  </li>
                        <li>Caste/Income Certificate</li>
                        <li>Fees Receipt of Institute</li>
                        <li>Passport size Photo</li>
                        <li>Goverment Verified Document (Aadhar card,Voter Id, etc)</li>
                    </ul>
                </div>
                <div class="help">
                    <p>HELPLINE</p>
                    <ul>
                        <li><strong>SOCIAL WELFARE:-</strong> 9008400010</li>
                        <li><strong>DEPARTMENT OF MINORITY:-</strong>080-22535931</li>
                        <li><strong>DEPARTMENT OF OBC:-</strong>8050770005</li>
                    </ul>
                    
                </div>
           </div>
       </section>  
  
</body>
</html>